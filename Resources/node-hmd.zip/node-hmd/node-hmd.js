'use strict';

module.exports = require(__dirname + '/build/Release/hmd.node');
