#ifndef SimpleQuad_ps_refl

const OVR::CAPI::D3D_NS::ShaderBase::Uniform SimpleQuad_ps_refl[] =
{
	{ "Color", 	OVR::CAPI::D3D_NS::ShaderBase::VARTYPE_FLOAT, 0, 16 },
};

#endif
